<?php
add_action("home_page_slider","get_home_page_slider");

function get_home_page_slider(){ 
        $count_slider=get_post_meta(get_the_ID(),"slider");
        $act="active";
        for($i=0;$i<$count_slider[0];$i++):
            $img=get_post_meta(get_the_ID(),"slider_".$i."_image");
            $image_url=wp_get_attachment_image_src($img[0],'full');
            $image_url=$image_url[0];
            $title=get_post_meta(get_the_ID(),"slider_".$i."_title")[0];
            $description=get_post_meta(get_the_ID(),"slider_".$i."_description")[0];
        ?>

          <div class="item <?php echo $act; ?>"> <img src="<?php echo $image_url; ?>" alt="" class="img-responsive">
            <div class="carousel-caption">
              <h2><?php echo $title; ?> </h2>
              <p><?php echo $description; ?></p>
            </div>
        </div>
       <?php  
       $act="";
       endfor; 
}
?>
